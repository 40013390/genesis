#__all__=["s,l"]

l=[1,2,3,4,5,6,7,8,9,10]
s="Welcome..."
n=10
def fun():
    print("Support fun()....")

if(__name__==   '__main()__'):
    print("L is :",l)
    print("S is :",s)

print("Name of support:",__name__)