import pymysql

connection =connection(
                        host="192.168.90.130",
                        port=3306,
                        user="usha",
                        password="usha123",
                        db="genesis"
                       );
cursor=connection.cursor();

query="select * from student";
cursor.execute(query);
records-cursor.fetchall();
print(records)
for record in records:
    print(record)
connection.close();