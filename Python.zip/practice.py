def cal(a):
    print("val:",a)
    a=a+200
    return a;
print("before")
res=cal(2)
print("aftr func:",res)