'''class Number():
    
    def __init__(self,no):
        self.no=no
   
    def __mul__(self,other):
        temp=Number(0)
        if(isinstance(other,Number)):
            print("Number obj passed")
            temp.no=self.no*other.no
        else:
            print("Number obj is not passed")
            temp.no=self.no*other
        return temp
n1=Number(10)
n2=Number(20)
n3=n1*n2;
print("n1.no:",n1.no)
print("n2.no:",n2.no)
print("n3.no:",n3.no)


class Number():
    def __init__(self,no):
        self.no=no
        
    def __ne__(self,other):
        print("Number.__lt__");
        return self.no != other.no
n1=Number(33)
n2=Number(20)
result=n1!=n2
print(result)

'''
class Number():
    def __init__(self,no):
        self.no=no
        
    def __str__(self,other):
        return ("number is:"+str(self.no))
    def __call__(self):
        print("Number.__cal__")
n1=Number(33)  
n1()#n1.__call__(n1)





 