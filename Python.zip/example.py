class example():
    count=20
    def __init__(self,i):
        self.i=i
        print("Default constr:",self.i)
    @classmethod
    def inc(cls):
        count=count+1
a=example(10)
a.inc()
print(a.count)