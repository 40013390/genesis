l="ushachinmaisai"
s={}
for i in l:
    if i in s:
        s[i]+=1
        
    else :
        s[i]=1
print(str(s))
'''print(type(s))
print(s.keys())
print(s.values())
        '''