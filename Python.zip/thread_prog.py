import threading
def thread_fun():
	print("i m child")
	
print("main Thread")
th1=threading.Thread(target=thread_fun)
th1.start()
print("main Thread ends")