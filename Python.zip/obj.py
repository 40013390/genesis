import pickle
L=[1,2,3,45]
L_B=pickle.dumps(L)
print(L_B)
L2=pickle.loads(L_B)
print(L2)


class Data():
    def __init__(self):
        self.i=10
        self.j=20
    def display(self):
        print("i:{},j:{}".format(self.i,self.j))
data=Data()
data.i=100
data.j=200
data.display()

fp=open("Data.dat","wb")
pickle.dumps(data,fp)
fp.close()

print(type(data_b))
print(data_b)