import matplotlib.pyplot as plt

def myper(percentage):
    return str(int(percentage))+"%"


shares=[10,20,30,40,50]
names=["LTTS","INFOSYS","WIPRO","HCL","MAHINDRA"]
#colors=["red","green","blue","yellow","cyan"]
colors=["#FF0000","#00FF00","#0000FF","yellow","#aabbcc"]
explods=(0.01,0.02,0.05,0.03,0.09)

plt.pie(shares,labels=names,colors=colors,counterclock=True,autopct=myper,explode=explods,shadow=True)
plt.legend(loc="upper left")
plt.show()