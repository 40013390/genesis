import matplotlib.pyplot as plt
import numpy.random as rd

names=["Name1","Name2","Name3"]

marks_m1=[40,50,80]
marks_m2=[30,20,40]
print(plt.style.available)
plt.style.use("Solarize_Light2")

plt.scatter(names,marks_m1,marker="o",label="Marks 1",s=100,color="red")

plt.xlabel("Student Name")
plt.ylabel("Marks")

plt.title("marks analysis",fontsize=10,fontweight="bold")
plt.legend(loc="lower center")
plt.show()
'''
import matplotlib.pyplot as plt
import numpy.random as rd

names=["Name1","Name2","Name3"]

marks_m1=[40,50,80]
marks_m2=[30,20,40]

print(plt.style.available)
plt.style.use("Solarize_Light2")

plt.scatter(names,marks_m1,marker="o",label="Marks 1",s=100,color="red")

plt.plot(names,marks_m1,marker="o",color="blue",markersize=5,linestyle="dotted",markerfacecolor="g",markeredgecolor="blue",linewidth=3,label="M1")

plt.plot(names,marks_m2,marker="*",color="red",markersize=5,linestyle="solid",markerfacecolor="g",markeredgecolor="blue",linewidth=3,label="M2")

plt.xlabel("Student Name")
plt.ylabel("Marks")

plt.title("marks analysis",fontsize=10,fontweight="bold")
plt.legend(loc="lower center")
plt.show()
'''
