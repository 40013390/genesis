class Student():
    count=0;
    def __init__(self,i):
        self.i=i
     
    def show(self):
        #self.i=a;
        
        print("type of self",type(self))
        print("type of self",type(self))  
        print("Student::show")
s1=Student(111)
s1.show()
s2=Student(123)
s2.show()
print("i val in s1:",s1.i)
print(type(s1))
print("i val in s2:",s2.i)
print(type(s2))
print("student count:",Student.count)
                                   