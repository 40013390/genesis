import matplotlib.pyplot as plt
import numpy.random as rd
import numpy as np

names=["Pre-Test","Post-Test"]
Pre_Test=[10,20,30,40,50,60,70,80,90]
Post_Test=[30,65,75,80,20,60,20,90,80]

box_pt = plt.boxplot([Pre_Test,Post_Test],labels=["PreTest","PostTest"],patch_artist=True)

colors=["green","blue"]
index=0
for patch in box_pt["boxes"]:
    patch.set_facecolor(colors[index])
    index=index+1
'''
m1=np.random.randomint(1,100,50)
m2=np.random.randomint(1,100,50)
'''



plt.legend(loc="upper left")
plt.show()
