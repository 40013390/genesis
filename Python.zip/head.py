import os
import os.path as p

files_list=os.listdir()
print(files_list)
for i in files_list :
    print(i,"=>",p.isfile(i))
'''
result=p.isfile("exp.py")
print(result)'''