def display():
    print("1 st");
    print("2-nd");
def sum(a,b):
    print("a:{},b={}".format(a,b))
    return a,b;
display()
#a=10
#b=20
a,b=sum(10,20)
print(a,b)
'''k=sum(10,20)
print(type(k))
a,b=k
print(a,b)'''


