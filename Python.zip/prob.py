import os
import os.path as path
import sys

stats=os.stat("support.py")
print(stats.st_size)

print("before")
os.system("support.py")
print("after")

print(sys.path)