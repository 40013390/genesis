import threading
import time
def thread_fun(n):
    tid=threading.currentThread().ident
    tname=threading.currentThread().name
    print("Child Thread id {} , name: {}".format(tid,tname))
    print("child thread : n :{}".format(n))
    for i in range(n):
        print("i am child thread.")
        time.sleep(1)
        

class MyThread():
    def __call__(self,n):
        for i in range(n):
            prit("I am child(clas) Thread.")
            time.sleep(1)
print("main Thread Started")
tid = threading.currentThread().ident
tname=threading.currentThread().name
#print("main thread id {},name:{}".format(tid,tname))
th1=threading.Thread(target=thread_fun,args=(5,))
th1.start() 
for i in range(5):
    print("main Thread running")
    time.sleep(1)
print("main thread ends")