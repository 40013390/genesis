from functools import reduce
def add(i,j):
    return i+j
l=[1,2,3,4,5]
result=reduce(add,l)
print(result)