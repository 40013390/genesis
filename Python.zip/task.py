file = open("Marks.txt", "r") 
lines = file.readlines() 
marks=set()
L=[]

for line in lines:
    temp=line.strip("\n").split(",")
    total=int (temp[1]) + int(temp[2]) + int(temp[3])
    marks.add(total)
    temp.append(total)
    L.append(temp)
    
marks=sorted(marks,reverse=True)
print("total marks=",marks)

file=open("Marks.txt","w")

for record in L:
    record.append(str(marks.index(record[4])))
    line="{},{},{},{},{},{}".format(record[0],record[1],record[2],record[3],record[4],record[5])
    file.write(line+"\n")
file.close()
