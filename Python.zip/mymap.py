def myMap(func,list_elements):
    l2=[]
    for i in list_elements:
      l2.append(func(i))
    return l2
       
    print(l2)
def inc(i):
    return i+1
l=[1,2,3,4,5]
res=myMap(inc,l)
print(res)