
my_string = 'I am a string'
print(dir(my_string))
