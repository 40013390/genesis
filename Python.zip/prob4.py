import re;
s1="AbC-d1"
s2=""
for ch in s1:
    if(re.match("[a-z]",ch)):
        s2=s2+ch.upper()
    elif(re.match("[A-Z]",ch)):
        s2=s2+ch.lower()
    else:
        s2 =s2+ch
print(s1)
print(s2)
