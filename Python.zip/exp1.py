try:
    f=open("file.txt","r")
    f.write("hello")
except FileNotFoundError as a:
    print("Exception is:",a.args)
    print("cmpltd")
    