l=[1,2,3,4,5,6]
l2=[]
for i in l:
    if i% 2 ==0:
        l2.append(i)
        print(i)
print(l2)
#l2.append("-")
#print(l2)