import socket
import threading
#thread to handle communictn to client
def client_handler(client_socket):  
    client_name=client_socket.getpeername()
    client_name=client_name[0]+"/"+str(client_name[1])
    while True:
        data=client_socket.recv(1024)
        data=data.decode()
        print("client handler {}".format(client_name),data)
        if(data=="exit"):
            break
        else:
            client_socket.send(data.upper().encode())
    client_socket.close()
    
server_socket=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
#binding
server_socket.bind(("127.0.0.1",9999))
server_socket.listen()
while True:
    print("waiting for client")
    client_socket,addr=server_socket.accept()
    th1=threading.Thread(target=client_handler,args=(client_socket,))
    th1.start()


    '''while True :
            data=client_socket.recv(1024)
        if(data):
            data=data.decode()
            print(data)
        else :
            break
    '''    
#print("from client:",data)


server_socket.close()