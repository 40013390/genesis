import matplotlib.pyplot as plt
import numpy.random as rd
import numpy as np
'''
marks_m1=[40,70,30,90,50,10]
plt.hist(marks_m1)

plt.legend(loc="lower center")
plt.show()


data=np.random.normal(1,100,size=100)
print(data)
plt.hist(data,histtype="step",color="red",label="Histogram")
plt.legend(loc="lower center")
plt.show()





names=["Name1","Name2","Name3","Name 4","Name 5"]

marks_m1=[40,70,30,90,50]
marks_m2=[30,60,70,20,55]

colors=["red","green","blue","yellow","cyan"]
widths=[0.1,0.2,0.3,0.4,0.5]

plt.bar(names,marks_m1,color=colors,label="marks",width=widths)

plt.xlabel("Student Name")
plt.ylabel("Marks")
plt.legend(loc="upper center")
plt.show()
'''

names=["Name1","Name2","Name3","Name 4","Name 5"]

marks_m1=[40,70,30,90,50]
marks_m2=[30,60,70,20,55]

plt.subplot(2,2,1)
plt.bar(names,marks_m1,color="cyan",label="marks 1")
plt.title("marks1 Analysis")
plt.xlabel("Student Name")
plt.ylabel("Marks")
plt.legend(loc="upper center")

plt.subplot(2,2,2)
plt.bar(names,marks_m2,color="green",label="marks 2")
plt.title("marks2 Analysis")
plt.xlabel("Student Name")
plt.ylabel("Marks")
plt.legend(loc="upper center")


plt.subplot(2,2,3)
plt.bar(names,marks_m1,color="red",label="marks 1")
plt.title("marks1 Analysis")
plt.xlabel("Student Names")
plt.ylabel("Marks")
plt.legend(loc="upper center")

plt.subplot(2,2,4)
plt.bar(names,marks_m1,color="yellow",label="marks 3")
plt.title("marks 3 Analysis")
plt.xlabel("Student Names 3")
plt.ylabel("Marks")
plt.legend(loc="upper center")
plt.show()