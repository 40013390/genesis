l1=[1,2,3,4,5]
l2=[3,4,5,3,1]
l3=[]
for i in range(0,len(l1)):
    l3.append(l1[i]+l2[i])
    
print(l3)
    