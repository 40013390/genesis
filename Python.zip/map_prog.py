l=[1,2,3,4,5]
l2=list(map((lambda x:x+1),l))
print(l2)
