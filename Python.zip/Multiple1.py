class A():
    def __init__(self):
        self.i=40
        print("Base A::",self.i)
        
          
class B():
    def __init__(self):
        self.i=20
        print("Base B::",self.i)
    
class C(A,B):
    def __init__(self):
        super(C,self).__init__()
        super(A,self).__init__()
        
        self.i=10
        print("Derived::__init__",self.i)
c=C()
print(c.i)
print(C.mro())
