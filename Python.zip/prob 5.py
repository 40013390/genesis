l=[1,2,4,6,7,8,9]
n=7

print(type(l))
print(type(n))
for outer in range(len(l)):
    for inner in range (0,len(l)):
        s=outer+inner
        if (outer!=inner and s==n):
            l.append((l[outer],l[inner]))
print(l)