def add(a,b):
	return a+b
 
def myFilter(f,L):
    while(len(L)>1):
        a,b =L[0],L[1]
        del(L[0:2])
        L.insert(0,f(a,b))
    return L[0]
    
L=[1,2,3,4,5]
result=myFilter(add,L)
print(result)