from pymysql import *

connection = Connection(
                        host="192.168.90.130",
                        port=3306,
                        user="usha",
                        password="usha123",
                        db="genesis",
                        cursorclass=cursors.DictCursor
                       );
cursor=connection.cursor();

query="insert into student values(%s,%s)";
count=cursor.execute(query,(4,'amina'));
connection.commit()
print("No. of records:",count);
records=cursor.fetchall();

for record in records:
    print(record)
connection.close();