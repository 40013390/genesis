'''f = lambda  x : x+1
print(f(20))#still there is f in dir()
print(dir())
'''
print((lambda y,x=200 :x+y)(20))
print(dir())