s="12345"
l=list(s)
#print(type(l))
#print(l)
s=0
for i in l:
    s=s+int(i)
print(s)