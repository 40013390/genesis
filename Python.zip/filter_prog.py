'''def is_even(i):
    print(i)
    return (i%2==0)
l=[1,2,3,4,5,6,7,8]
print(list(filter(is_even,l)))
'''
l=[1,2,3,4,5]
l2=list(map((lambda x:x%2==0),l))
print(l2)
