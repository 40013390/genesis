from exp2 import MyException
print("before")


try:
    a=10
    b=10
    '''l=[1,2,3,4]
       j=j+1
       l[7]=7
    c=a/b
    print(l)
    print(c)
    print("after")
    '''
    if(a==b):
        myExp=MyException("Something went wrong")
        raise myExp
except (ZeroDivisionError,IndexError ) as e:
    print("Exeption:",e.args)
except IndexError as q:
    print("Exception :",q.args)
except Exception as e:
   print("Exception :",e.args)
else:
   print("else block")
finally :
    print("Finally Block")
print("Done")