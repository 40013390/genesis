'''class Base():
    def __init__(self):
        print("self type in base:",type(self))
        print("Base::__init__")
        self.i=10
              
    def display(self):
            print("Base:display",self.i)
class Derived(Base):
    def __init__(self):
        super().__init__()          
        print("Derived.__init__")
d=Derived()
#d.display()
#print(dir(d))
print("i in d:",d.i)'''


from support import *
i=10

print(dir())


print("name of main :",__name__)
print("doc:",__doc__)
print("file:",__file__)
print("  Support  ")
print("name:",support.__name__)
print("doc:",support.__doc__)
print("file:",support.__file__)