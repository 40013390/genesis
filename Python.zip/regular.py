import re;
'''
pattern="Hello"
string="123Hello"
print(re.match(pattern,string))
'''
print(re.match("[123ab]","123Aab"))
print(re.match("[123]+ab","123ab"))
print(re.match("[123]*a","12123aa"))
print(re.match("[^a-f]*$","jk"))
print(re.match("[\D]{5}$","Aa%"))
print(re.match("[\d]{5}","Z1233456"))







