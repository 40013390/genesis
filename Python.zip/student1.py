class student():
    count=10;
    def __init__(self,i):
        self.i=i
        self.__pr=111 
        print("Std::__init__")
       
           
    def show(self):
        print("Student::show:",self.i)
    @classmethod
    def mod_count(cls):
        cls.count=cls.count+100;
    
s1=student(11)
print("s1.count:",s1.count)
print("Student count:",student.count)
s1.mod_count();
print("s1.count:",s1.count);
print("Student.count:",student.count)


