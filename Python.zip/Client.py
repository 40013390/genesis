import socket

client_socket=socket.socket(socket.AF_INET,socket.SOCK_STREAM)

client_socket.connect(("127.0.0.1",9999))
'''
file= open("Client.py","r")
lines=file.readlines()
for data in lines:
    data=data.encode()
    client_socket.send(data)
'''
while True:
    data=input()
    data=data.encode()
    client_socket.send(data)
    data=client_socket.recv(1024)
    print("server",data.decode().encode())
    if(data=="exit"):
        break