try:
    a=10
    b=0
    
    c=a//b
    print(c)

except ZeroDivisionError as s :
    print("Exception is:",s.args)
    print("cmpltd")

else :
    print(c)
finally :
    print("exception Handling cmpltd")