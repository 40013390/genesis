l=[]
l=[1,1.23,"Text",True,[10,20,30]]
l[1:3]=[9,10,"False"];
print(l)
l.append(33)
l.append([1,2,3])
print("after append :" , l)
del(l[2])
print("After del:" ,l)
val=l.pop(2)
print("After pop: ",val)
print(l)
l.insert(13,444)
print("After Inserting :",l)
l.extend("True")
print("after extend:",l)
l.insert(-3,33)
print(l)