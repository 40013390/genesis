class A():
    print("Base A::")
    pass
    
   
class B():
    print("Base B::")
    pass
class C(A,B):
    def __init__(self):
        self.i=10
        print("Derived::__init__")
c=C()
print(c.i)
print(C.mro())
                 